﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace LinuxConsoleBrowser
{
    class Program
    {
        static string currentDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        static int selectedIndex = 0;
        static string[] entries;
        static int nameColumnWidth = 40;
        static int pageSize = 15;
        static int totalPages = 1;
        static int currentPage = 0;

        static void Main(string[] args)
        {
            Console.CursorVisible = false;

            while (true)
            {
                LoadAndDisplayDirectory(currentDirectory);

                var key = Console.ReadKey(true).Key;

                switch (key)
                {
                    case ConsoleKey.UpArrow:
                        if (selectedIndex > 0) selectedIndex--;
                        break;

                    case ConsoleKey.DownArrow:
                        if (selectedIndex < entries.Length - 1) selectedIndex++;
                        break;

                    case ConsoleKey.PageUp:
                        if (currentPage > 0) currentPage--;
                        selectedIndex = currentPage * pageSize;
                        break;

                    case ConsoleKey.PageDown:
                        if (currentPage < totalPages - 1) currentPage++;
                        selectedIndex = currentPage * pageSize;
                        break;

                    case ConsoleKey.Enter:
                        string selectedPath = entries[selectedIndex];
                        if (Directory.Exists(selectedPath))
                        {
                            currentDirectory = selectedPath;
                            selectedIndex = 0;
                            currentPage = 0;
                        }
                        else if (File.Exists(selectedPath))
                        {
                            OpenFile(selectedPath);
                        }
                        break;

                    case ConsoleKey.Escape:
                        GoToParentDirectory();
                        break;

                    case ConsoleKey.Q:
                        Console.Clear();
                        Console.WriteLine("Wyjście z programu.");
                        return;

                    case ConsoleKey.F1:
                        CreateNewFolder();
                        break;

                    case ConsoleKey.F2:
                        CreateNewTextFile();
                        break;
                }
            }
        }

        static void LoadAndDisplayDirectory(string directory)
        {
            Console.Clear();

            entries = Directory.GetDirectories(directory, "*", SearchOption.TopDirectoryOnly)
                               .Where(d => !Path.GetFileName(d).StartsWith("."))
                               .Concat(
                                   Directory.GetFiles(directory, "*", SearchOption.TopDirectoryOnly)
                                   .Where(f => !Path.GetFileName(f).StartsWith("."))
                               )
                               .ToArray();

            if (entries.Length == 0)
            {
                selectedIndex = 0;
                totalPages = 1;
                currentPage = 0;
            }
            else
            {
                totalPages = (int)Math.Ceiling((double)entries.Length / pageSize);

                if (selectedIndex >= entries.Length)
                    selectedIndex = entries.Length - 1;

                if (currentPage >= totalPages)
                    currentPage = totalPages - 1;
            }

            Console.WriteLine($"Katalog: {directory}");
            Console.WriteLine(new string('-', 40));

            if (entries.Length == 0)
            {
                Console.WriteLine("Brak elementów w tym katalogu.");
                return;
            }

            for (int i = currentPage * pageSize; i < Math.Min((currentPage + 1) * pageSize, entries.Length); i++)
            {
                Console.SetCursorPosition(0, 2 + i - currentPage * pageSize);

                if (i == selectedIndex)
                {
                    Console.BackgroundColor = ConsoleColor.DarkGreen;
                    Console.ForegroundColor = ConsoleColor.Black;
                }

                string entryName = Path.GetFileName(entries[i]);
                entryName = entryName.Length > nameColumnWidth ? entryName.Substring(0, nameColumnWidth) : entryName;
                Console.Write(entryName.PadRight(nameColumnWidth));

                Console.ResetColor();
            }

            DisplayFileInfo();

            if (totalPages > 1)
            {
                Console.SetCursorPosition(0, 2 + Math.Min((currentPage + 1) * pageSize, entries.Length));
                Console.WriteLine($"Strona {currentPage + 1}/{totalPages}  (PageUp/PageDown)");
            }
        }

        static void DisplayFileInfo()
        {
            if (entries.Length == 0 || selectedIndex >= entries.Length) return;

            string selectedPath = entries[selectedIndex];

            Console.SetCursorPosition(42, 2);
            Console.WriteLine("Informacje o pliku/katalogu:");
            Console.SetCursorPosition(42, 3);
            Console.WriteLine(new string('-', 35));

            try
            {
                if (Directory.Exists(selectedPath))
                {
                    Console.SetCursorPosition(42, 5);
                    Console.WriteLine($"Typ: Katalog");
                    Console.SetCursorPosition(42, 6);
                    Console.WriteLine($"Zawartość: {Directory.GetFileSystemEntries(selectedPath).Length} elementów");
                    Console.SetCursorPosition(42, 7);
                    Console.WriteLine($"Utworzono: {Directory.GetCreationTime(selectedPath)}");
                }
                else if (File.Exists(selectedPath))
                {
                    FileInfo fileInfo = new FileInfo(selectedPath);
                    Console.SetCursorPosition(42, 5);
                    Console.WriteLine($"Typ: Plik ({fileInfo.Extension})");
                    Console.SetCursorPosition(42, 6);
                    Console.WriteLine($"Rozmiar: {fileInfo.Length / 1024.0:F2} KB");
                    Console.SetCursorPosition(42, 7);
                    Console.WriteLine($"Utworzono: {fileInfo.CreationTime}");
                    Console.SetCursorPosition(42, 8);
                    Console.WriteLine($"Zmodyfikowano: {fileInfo.LastWriteTime}");
                }
            }
            catch (Exception ex)
            {
                Console.SetCursorPosition(42, 5);
                Console.WriteLine($"Błąd: {ex.Message}");
            }
        }

       static void OpenFile(string filePath)
{
    try
    {
        string fileExtension = Path.GetExtension(filePath).ToLower();
        string editor = "xdg-open"; 

        // Obsługa plików tekstowych
        if (fileExtension == ".txt" || fileExtension == ".log" || fileExtension == ".md")
        {
            editor = "nvim"; 
        }
        // Obsługa plików wideo
        else if (fileExtension == ".mp4" || fileExtension == ".mkv" || fileExtension == ".avi")
        {
            editor = "mpv"; 
        }
        // Obsługa plików MP3
        else if (fileExtension == ".mp3")
        {
            editor = "vlc"; 
        }

    
        Process.Start(new ProcessStartInfo
        {
            FileName = editor,
            Arguments = filePath,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        });
    }
    catch (Exception ex)
    {
        Console.Clear();
        Console.WriteLine($"Nie udało się otworzyć pliku: {ex.Message}");
        Console.WriteLine("Naciśnij dowolny klawisz, aby kontynuować.");
        Console.ReadKey(true);
    }
}


        static void GoToParentDirectory()
        {
            var parentDirectory = Directory.GetParent(currentDirectory);
            if (parentDirectory != null && parentDirectory.FullName.StartsWith(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)))
            {
                currentDirectory = parentDirectory.FullName;
                selectedIndex = 0;
                currentPage = 0;
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Jesteś w katalogu głównym użytkownika. Nie można wrócić wyżej.");
                Console.WriteLine("Naciśnij dowolny klawisz, aby kontynuować.");
                Console.ReadKey(true);
            }
        }

        static void CreateNewFolder()
        {
            Console.Clear();
            Console.WriteLine("Wprowadź nazwę nowego folderu:");
            string folderName = Console.ReadLine();
            string newFolderPath = Path.Combine(currentDirectory, folderName);

            if (Directory.Exists(newFolderPath))
            {
                Console.WriteLine("Folder o tej nazwie już istnieje.");
            }
            else
            {
                try
                {
                    Directory.CreateDirectory(newFolderPath);  // Correctly create the folder
                    Console.WriteLine($"Utworzono folder: {newFolderPath}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Błąd podczas tworzenia folderu: {ex.Message}");
                }
            }

            Console.WriteLine("Naciśnij dowolny klawisz, aby kontynuować.");
            Console.ReadKey(true);

            LoadAndDisplayDirectory(currentDirectory);  // Reload directory after folder creation
        }

        static void CreateNewTextFile()
        {
            Console.Clear();
            Console.WriteLine("Wprowadź nazwę nowego pliku tekstowego (bez rozszerzenia):");
            string fileName = Console.ReadLine();
            string newFilePath = Path.Combine(currentDirectory, fileName + ".txt");

            if (File.Exists(newFilePath))
            {
                Console.WriteLine("Plik o tej nazwie już istnieje.");
            }
            else
            {
                try
                {
                    File.WriteAllText(newFilePath, "");  // Creates an empty file
                    Console.WriteLine($"Utworzono plik: {newFilePath}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Błąd podczas tworzenia pliku: {ex.Message}");
                }
            }

            Console.WriteLine("Naciśnij dowolny klawisz, aby kontynuować.");
            Console.ReadKey(true);

            LoadAndDisplayDirectory(currentDirectory);  // Reload directory after file creation
        }
    }
}
